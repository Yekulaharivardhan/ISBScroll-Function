import React from "react";
import { Link } from "react-router-dom";
import "./homePageStyle.css"

export default class AboutPage extends React.Component {
  render() {
    return (
      <div className="page-container page">
      <div className="about-page inner-container">
        <div className="container">
        <div className="mycontainer_cls">
          <h3>Learning Objectives</h3>
         <p> Does your work involve collaborating with people from either different levels, geographical locations, or functions/ areas of expertise? What approaches have you found helpful to make it efficient? </p>
         <hr />
         <p> I will evaluate all the pros and cons of the given situation, then I will select the one with has more pros and at the same time more effective</p>
          </div></div>

          <div className="container" style={{marginTop:"0px"}}>
      <h4 style={{margin:"auto"}}>Peer responses</h4>
<p>I will evaluate all the pros and cons of the given situation, then I will select the one with has more pros and at the same time more effective
</p><h5>-MEERA, HYDERABAD</h5>

          <div className="navigation">
         
            <Link to="/DPage">
            <button className="submit_button">Next <img src="./images/downarrow.png" alt="" />  </button>
            </Link>
            </div>
        </div>
      </div></div>
    );
  }
}
