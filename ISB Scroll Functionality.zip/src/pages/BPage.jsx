import React from "react";
import { Link } from "react-router-dom";

export default class BPage extends React.Component {
  render() {
    return (
      <div className="page-container page">
      <div className="about-page inner-container">
        <div className="container">
        <div className="mycontainer_cls">
            
            <h3>Learning Objectives</h3>
            
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis reiciendis culpa consequatur ratione et odio eius omnis enim at distinctio numquam officiis deleniti maiores perspiciatis ducimus architecto nisi cupiditate, inventore non, reprehenderit fugiat! Dolorum repellendus odio aliquam accusamus asperiores fuga deserunt aut voluptatibus error! Rem quibusdam iure iste sed nisi.
            </p></div>
          
         
          <div className="navigation">
            <Link to="/CPage">
            <button className="submit_button">Next <img src="./images/downarrow.png" alt="" />  </button>
            </Link>
          </div>
          </div></div>
      </div>
    );
  }
}
