import React from 'react';
import "./NavBar.css"
import Nav from 'react-bootstrap/Nav';



const NavBar = () => {
    return (
        <div>
<div className="nav_bar" ></div>

<nav className="navbar navbar-expand-lg navbar-light bg-light" style={{}}>
    <a className="navbar-brand me-2" href="https://isbonline.com/">
     <img className='brand_logo' src="https://s3-alpha-sig.figma.com/img/fd6a/ae8b/4664790ca763c73eacd154e075e70ebc?Expires=1663545600&Signature=IfJeRFyyyR3QtErIOYbbmIlUgCLa-pXx1BIKZjpJSM-C5DwJQsDHKg5bQNjKdPbTm7YJbA44waIzNPMwG93RpgfRkgLv2WI39lFHuC9SWl6BGKIc6P8SBM6sE~UHpgU0JLA8A0WX3KrIHXuhQTHTGYWgMMsY0XLhgC5-thKuzpEIBQVaRCHVR0gsfNJavwjAZaxhBFTnxbdNlnb~Me1EAg6yyDKkDSgqbzqLYqIC2PUr906LMGbRa3BAO-Pbp6C4dwzqIA6j29hu1ivQVY4UqvENvKZDbLr26gDUjs4UDwlMINCDLwgdzAZTKCN9W3nYNNqv~JjZLGSJu7EE34F5uw__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA" alt="" />| Online
     </a>
     <Nav.Item>
     <img className='user_avatar' src="https://s3-alpha-sig.figma.com/img/d918/ced4/d006edb135bca7573615fc4beb6858bc?Expires=1663545600&Signature=fnnYZh0prQYtSx4MJEdFvW7n7pn7HXsELGD0uW7MEQSSKp3NWqkMDAEVlKB6DpB6ZDGshSJlEa648VQEs6O3fU4lUA43D77mjoQcFLNRwdgHnhf9gx0TtwjTFTwf6bcqlAKfotfJCA-epaO5Dfk9q7ajHRiuQAoW4nSbQTyRcR5X7lxu0v59Z6tP~Wfn-WIvD2tNyoYrTNnxAzAiaOA7LIpqKV8n1cnRX4CTh6-mJooaoViNMHezFniNp~O9z4o2aPq~DvBUGyzydU2MPR97kdCbUyn5bTjo9Pb8Gwiuv932hUm1JaFk7s8hKsHPC5F9bPcdgYS~TBKkY1jUz9QB3Q__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA" alt="" />
     </Nav.Item>    
    </nav>

        </div>
    );
};

export default NavBar;