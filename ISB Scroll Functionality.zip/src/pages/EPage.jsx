import React from 'react';
import "./homePageStyle.css";
// import './LandNavbar.css'
import { Link } from "react-router-dom";


const EPage = () => {
    return (
        <>
  <div className="page-container page">
      <div className="about-page inner-container">
        <div className="container" >
        <div className="mycontainer_cls">          
        <h5>How many efforts did the rescue mission involve in the Chilean mining case?</h5>
        </div>

        <div className="select_options" style={{lineHeight:"50px", marginTop:"10px"}}>
        <div className="form-check">
  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
  <label className="form-check-label" htmlFor="flexRadioDefault1">
  1.	Individual efforts of Survival, Managerial, and Technical
  </label>
</div>


<div className="form-check">
  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" />
  <label className="form-check-label" htmlFor="flexRadioDefault2">
  2.	Hierarchal efforts on Survival, Managerial, and Technical
  </label>
</div>


  <div className="form-check">
  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
  <label className="form-check-label" htmlFor="flexRadioDefault1">
  3.	Individual and Interlinking efforts on Survival, Managerial, and Technical. 
  </label>
</div>


  <div className="form-check">
  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
  <label className="form-check-label" htmlFor="flexRadioDefault1">
  4.	Interlinking efforts on Survival, Managerial, and Technical
  </label>
</div>
  </div>      
        
        
           <div className="navigation">
            <Link to="/FPage" style={{textDecoration:"none"}}>
            
            <button className="submit_button">Submit </button>
            
            <span><p style={{ paddingTop:"20px"}}><img src="./images/star.png" alt="" /> 1 Point</p></span>
            </Link>
          </div>
        </div> </div></div>

        </>
    );
};

export default EPage;