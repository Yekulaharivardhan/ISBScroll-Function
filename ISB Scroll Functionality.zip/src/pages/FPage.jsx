import { Link } from "react-router-dom";
import "./homePageStyle.css";

import React from 'react';

const FPage = () => {
    return (
        <>
      
      <div className="page-container page">
      <div className="about-page inner-container">
        <div className="container" 
        // style={{width:"850px",margin:"auto", padding:"20px",marginTop:"80px",}} 
        >
        <div className="myheader_cls">
        
        <h5>How many efforts did the rescue mission involve in the Chilean mining case?</h5>
        </div>

<div className="main_container" style={{display:"flex",backgroundColor:"gray", }}>


        <div className="select_options" style={{lineHeight:"50px", marginTop:"10px"}}>
          <div className="option_container">
        <div className="form-check">
  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
  <label className="form-check-label" for="flexRadioDefault1">
  1.	Individual efforts of Survival, Managerial, and Technical
  </label>
</div></div>

<div className="option_container" >
<div className="form-check">
  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
  <label className="form-check-label" for="flexRadioDefault1">
  2.	Hierarchal efforts on Survival, Managerial, and Technical
  </label>
</div></div>

<div className="option_container" >
  <div className="form-check">
  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
  <label className="form-check-label" for="flexRadioDefault1">
  3.	Individual and Interlinking efforts on Survival, Managerial, and Technical. 
  </label>
</div></div>

<div className="option_container" >
  <div className="form-check">
  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
  <label className="form-check-label" for="flexRadioDefault1">
  4.	Interlinking efforts on Survival, Managerial, and Technical
  </label>
</div></div>
  </div>     

  <div className="pie_chart" >
  <p>Graph View</p>
{/* <ul className="burger_button"><img src="./images/dash.png" alt="" /> </ul>
<ul className="burger_button"><img src="./images/dash.png" alt="" /> </ul>
<ul className="burger_button"><img src="./images/dash.png" alt="" /> </ul> */}
<p>Table View</p>
</div> </div>




<div></div>

</div>
        <div className="navigation">
            <Link to="/GPage">
            <button className="next_button" style={{margin:"auto"}}>Next <img src="./images/downarrow.png" alt="" />  </button>
            </Link>
          </div>

           </div>
        </div>
      </>
    );
};

export default FPage;
