import React, { Component } from "react";
import "./App.css";
import APage from "./pages/APage";
import { Switch, Route, withRouter, BrowserRouter } from "react-router-dom";
import CPage from "./pages/CPage";

import { TransitionGroup, CSSTransition } from "react-transition-group";
import { withRouter as Router } from "react-router-dom";
import "./pageTransitions/slideTransitiontwo.scss";
import BPage from './pages/BPage';
import DPage from './pages/DPage';
import EPage from './pages/EPage';
import FPage from './pages/FPage';
import GPage from './pages/GPage';
import HPage from './pages/HPage';
// import NavBar from './pages/NavBar';
import AAStartExam from '././pages/FinalExamPages/AAStartExam';




class App extends Component {
constructor(props) {
  super(props);
  this.state = {
    prevDepth: this.getPathDepth(this.props.location)
  };
}

componentWillReceiveProps() {
  this.setState({ prevDepth: this.getPathDepth(this.props.location) });
}

getPathDepth(location) {
  let pathArr = location.pathname.split("/");
  pathArr = pathArr.filter(n => n !== "");
  return pathArr.length;
}

  render() {
    const { location } = this.props;

    const currentKey = location.pathname.split("/")[1] || "/";
    const timeout = { enter: 800, exit: 400 };

    return (
      <TransitionGroup component="div" className="App">
        <CSSTransition
          key={currentKey}
          timeout={timeout}
          classNames="pageSlider"
          mountOnEnter={false}
          unmountOnExit={true}
        >
<div
  className={
    this.getPathDepth(location) - this.state.prevDepth >= 0
      ? "left"
      : "right"
  }
>

<BrowserRouter>
</BrowserRouter>

  <Switch location={location}>
 
    <Route path="/" exact component={APage} />
    <Route path="/BPage" exact component={BPage} />
    <Route path="/CPage" exact component={CPage} />
    <Route path="/DPage" exact component={DPage} />
    {/* <Route path="/NavBar" exact component={NavBar} /> */}
     <Route path="/EPage" exact component={EPage} />
    <Route path="/FPage" exact component={FPage} />
    <Route path="/GPage" exact component={GPage} />
    <Route path="/HPage" exact component={HPage} />
    <Route path="/AAStartExam" exact component={AAStartExam} />
    <Route path="/HPage" exact component={HPage} />
    <Route path="/HPage" exact component={HPage} />
    AAStartExam
  </Switch>
</div>
        </CSSTransition>
      </TransitionGroup>
    );
  }
}

export default Router(App);
