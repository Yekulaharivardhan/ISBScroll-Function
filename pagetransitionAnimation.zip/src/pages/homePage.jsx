import React from "react";
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import "./homePageStyle.scss";

import { Link } from "react-router-dom";
import { Button } from "react-bootstrap";

export default class HomePage extends React.Component {
  render() {
    return (<>
       <div className="page-container page">
       <div className="home-page inner-container">
          <div className="welcome-container">
          
          <div className="container">

          
         
            <div className="mycontainer_cls">
<h1>Learning Objectives 1</h1>
<p className="">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<li>Differentiate between Intuitive Thinking and Reason Based Thinking
Identify the characteristics of Intuitive Thinking and Reason Based Thinking
Explain Naïve Realism
Identify situations that involve illusion of objectivity</li>
<div className="navigate">
            <Link to="/homePagetwo">
              <button className="btn btn-primary">Click to Next Page</button>
            </Link>
          </div>

            </div>
          </div>




        
          
          
          
          </div>
          
          <div className="our-story">
           
            
          </div>
         
        </div>
      </div>
      </>
    );
  }
}
