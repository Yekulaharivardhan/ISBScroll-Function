import React from "react";
import { Link } from "react-router-dom";

export default class HomePageTwo extends React.Component {
  render() {
    return (
      <div className="page-container page">
        <div className="about-page inner-container">
          <div className="our-story">
            <div className="container mycontainer_cls">
            <h1>Harivardhan</h1>
            
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis reiciendis culpa consequatur ratione et odio eius omnis enim at distinctio numquam officiis deleniti maiores perspiciatis ducimus architecto nisi cupiditate, inventore non, reprehenderit fugiat! Dolorum repellendus odio aliquam accusamus asperiores fuga deserunt aut voluptatibus error! Rem quibusdam iure iste sed nisi.
            </p></div>
          </div>
          <div className="navigation">
            <Link to="/">
              <button className="btn">Previous Lession</button>
            </Link>
          </div>
          <div className="navigation">
            <Link to="/about">
              <button className="btn">Next Lession</button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
}
