import React from "react";
import { Link } from "react-router-dom";
import { Container } from 'react-bootstrap/Container';

export default class AboutPageTwo extends React.Component {
  render() {
    return (<>
      
      <div className="page-container page">
        <div className="about-page inner-container">
          <div className="our-story">
          <div className="Container mycontainer_cls" >
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptas velit, consequatur sit vel eum quos architecto, ducimus maiores facere nemo aliquam harum sequi dolor quam cumque ab a nihil laborum vitae magnam illum omnis. Quod illum excepturi inventore sapiente incidunt dicta ipsa quas maxime, voluptate modi provident. Similique, animi numquam?
          </div></div>
          <div className="navigation">
            <Link to="/about">
              <button className="btn">Go Back</button>
            </Link>
          </div>
          <div className="navigation">
            <Link to="/">
              <button className="btn">Go forward</button>
            </Link>
          </div>
        </div>
      </div></>
    );
  }
}
