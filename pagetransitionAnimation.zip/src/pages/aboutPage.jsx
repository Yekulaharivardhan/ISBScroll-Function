import React from "react";
import { Link } from "react-router-dom";

export default class AboutPage extends React.Component {
  render() {
    return (
      <div className="page-container page">
        <div className="about-page inner-container">
          <div className="our-story">
          <div className="container mycontainer_cls">
          <h1>This is testing</h1>
           Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic asperiores accusantium sed odit deserunt minima impedit accusamus, voluptatem autem voluptate vitae eius, pariatur nulla cupiditate incidunt doloribus voluptatibus quis odio! Exercitationem corporis aut iure, voluptatum odio veritatis porro quod modi velit animi officiis sit inventore? Tempore commodi iste vero sequi enim voluptatibus voluptate, corporis minima excepturi facilis nam non aliquam quod, numquam maiores repudiandae explicabo velit itaque sunt perferendis dolorum ad, similique vel veritatis. Veritatis accusantium perspiciatis aut quas eos id. Sed voluptate exercitationem quisquam placeat magnam vitae porro dicta, accusantium recusandae consectetur odio nesciunt! Distinctio laboriosam quo dolor suscipit!
          </div></div>
          <div className="navigation">
            <Link to="/aboutPageTwo">
              <button className="btn">Next Lession</button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
}
